'use client'

import { useChat } from 'ai/react'
import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function GrammarCorrectionChat() {
  const { messages, input, handleInputChange, handleSubmit } = useChat()
  const [isChecking, setIsChecking] = useState(false)

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setIsChecking(true)
    handleSubmit(e).finally(() => setIsChecking(false))
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Grammar Correction Bot</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <form onSubmit={onSubmit}>
            <Textarea
              value={input}
              onChange={handleInputChange}
              placeholder="Enter text to check for grammar..."
              className="min-h-[100px]"
            />
            <Button type="submit" className="mt-2" disabled={isChecking}>
              {isChecking ? 'Checking...' : 'Check Grammar'}
            </Button>
          </form>
          {messages.length > 0 && (
            <div className="mt-4">
              <h3 className="font-semibold">Corrected Text:</h3>
              <p className="mt-2 p-2 bg-green-50 rounded">{messages[messages.length - 1].content}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

